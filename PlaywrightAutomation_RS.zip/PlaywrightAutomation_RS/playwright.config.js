// @ts-check
import { defineConfig, devices } from '@playwright/test';


/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
// import path from 'path';
// dotenv.config({ path: path.resolve(__dirname, '.env') });

/**
 * @see https://playwright.dev/docs/test-configuration
 * 
 *==> defineConfig isn't just for TypeScript types; it's the function that actually validates
 *  and normalizes your config object, and export default is how the Playwright test runner discovers
 *  it in the first place.
 */

   export default defineConfig({
  testDir: './tests',
  timeout : 60*1000,
  expect : {
      timeout : 8000,
  },
 reporter: [['html', { open: 'on-failure' }]],
  use: {
    actionTimeout: 10 * 1000,
    navigationTimeout: 30 * 1000,
   browserName : 'chromium',
   headless : false,
   video: 'on',
   //screenshot : 'on',
   //trace: 'retain-on-failure'
  }


});

