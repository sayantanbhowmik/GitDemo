const {test,expect} = require('@playwright/test')

test('CLient app test',async({page})=>
{
    const firstName = page.locator("#firstName")
    const lastName = page.locator("#lastName")
    const email = page.getByPlaceholder("email@example.com")
    const phoneNo = page.locator("#userMobile")
    const dropDOwn = page.locator("[formcontrolname='occupation']")
    const radioBtn = page.locator("input[type='radio'][value='Male']")
    const pwd = page.getByPlaceholder("enter your passsword")
    
    const confirmPwd = page.locator("#confirmPassword")
    const checkbox = page.locator("[formcontrolname='required']")
    const registerBtn = page.locator("[value='Register']")
    const loginBtn = page.locator("button[routerlink='/auth']")
    const emaiId = "dummyw1ebs12ite@rahulshettyacademy.com"
    const pwdValue = "Ind@1995"
    const loginpage_loginBtn = page.getByRole('button',{name : 'login'})
    const dashboardHdr = page.locator("[routerlink='/dashboard']")
    const productNames = page.locator(".card-body h5")
    const products = page.locator('div.card-body')
    const cartBtn = page.getByRole('listitem').getByRole('button',{name : 'Cart'})
    const checkOut = page.getByRole("button",{name:'Checkout'})
    const selectCountry = page.getByPlaceholder('Select Country')
    const dropDown_Country = await page.locator("section.ta-results")
    const shippingInfo_email = page.locator(".user__name label")
    const placeOrder = page.getByText('PLACE ORDER')
    const orderConfirmation = page.getByText('Thankyou for the order.')
    const orderID = page.locator("label.ng-star-inserted")
    const orderTab = page.locator("button[routerlink='/dashboard/myorders']")
    const orderSummary = page.locator("div.email-title")
    

    await page.goto("https://rahulshettyacademy.com/client/#/auth/login")
    // await page.locator("p.login-wrapper-footer-text").click()
    // await firstName.fill("sb1")
    // await lastName.fill("test")
    // await email.fill(emaiId)
    // await phoneNo.fill("1234567890")
    // await dropDOwn.selectOption("Engineer")
    // await radioBtn.check()
    // await pwd.fill(pwdValue)
    // await confirmPwd.fill(pwdValue)
    // await checkbox.click()
    // await registerBtn.click()
    // await expect(page.locator("div[class*='login-wrapper my-auto'] h1")).toContainText("Account Created Successfully")
    // await loginBtn.click()

    await email.fill(emaiId)
    await pwd.fill(pwdValue)
    await loginpage_loginBtn.click()
   // await expect(dashboardHdr).toBeVisible()
   // console.log(await productNames.first().textContent())
   await page.waitForLoadState('networkidle') // below is substitute of this line
    await productNames.last().waitFor()
   // const allProducts = await productNames.allTextContents()
   // console.log(allProducts)
    const countOfProduct =await  productNames.count()
    console.log(countOfProduct)
    const productName = "ZARA COAT 3"
    // for(let i = 0;i<countOfProduct; ++i)
    // {
       
    //     if(await productNames.nth(i).locator("b").textContent() === productName)
    //     {
    //         await products.nth(i).locator("text = Add To Cart").click()   
    //         break     
            
    //     }
    // }
    await products.filter({hasText : productName}).getByRole('button',{name : 'Add To Cart'}).click()

    await cartBtn.click()
    await page.locator("div li",{hasText:productName}).waitFor()
    await expect(page.getByText(productName)).toBeVisible()
    await checkOut.click()

    await selectCountry.pressSequentially("ind")
    await page.getByRole('button',{name : 'India'}).nth(1).click()
    //await page.pause()
    expect(shippingInfo_email).toHaveText(emaiId)
    await placeOrder.click()
    //await page.pause()
    await expect(orderConfirmation).toBeVisible()
    // const orderNumber = (await orderID.textContent()).trim()
    // const finalOrderNo = orderNumber.replaceAll("|","").trim()
    // console.log("Order Number is "+finalOrderNo)
     
    // await orderTab.click()


    //await page.pause()
    // const order_InOrderHistroy = page.locator("[scope='row']",{hasText : finalOrderNo})
    // expect(order_InOrderHistroy).toHaveText(finalOrderNo)
    // await order_InOrderHistroy.locator("xpath=following-sibling::td /button").locator("text =View").click()
    // await page.pause()
    // await expect(orderSummary).toContainText("order summary")

//     const rows = page.locator("tbody tr")
//     for(let i = 0;i<await rows.count();i++)
//     {
        
//         const rowOrderID = await rows.nth(i).locator('th').textContent()
//         if(orderNumber.includes(rowOrderID))
//         {
//             await page.pause()
//             console.log("Inside if")
//             await rows.nth(i).locator("button").locator("text =View").click()
//             break 
//         }
//     }
//    // await page.pause()
//     await expect(orderSummary).toContainText("order summary")
//     const orderNo_OrderSummary =  page.locator("div.col-text")
//     expect(orderNo_OrderSummary).toHaveText(finalOrderNo)
   




}
)