const {test,expect} = require('@playwright/test')


test('CLient app test',async({page})=>
{
    const firstName = page.locator("#firstName")
    const lastName = page.locator("#lastName")
    const email = page.locator("#userEmail") 
    const phoneNo = page.locator("#userMobile")
    const dropDOwn = page.locator("[formcontrolname='occupation']")
    const radioBtn = page.locator("input[type='radio'][value='Male']")
    const pwd = page.locator("#userPassword")
    const confirmPwd = page.locator("#confirmPassword")
    const checkbox = page.locator("[formcontrolname='required']")
    const registerBtn = page.locator("[value='Register']")
    const loginBtn = page.locator("button[routerlink='/auth']")
    const emaiId = "dummyw1ebs1ite@rahulshettyacademy.com"
    const pwdValue = "Ind@1995"
    const loginpage_loginBtn = page.locator("#login")
    const dashboardHdr = page.locator("[routerlink='/dashboard']")
    const productNames = page.locator(".card-body h5")
    const products = page.locator('div.card-body')
    const cartBtn = page.locator("[routerlink='/dashboard/cart']")
    const checkOut = page.locator("button[type='button']",{hasText:'Checkout'})
    const selectCountry = page.locator("[placeholder='Select Country']")
    const dropDown_Country = await page.locator("section.ta-results")
    const shippingInfo_email = page.locator(".user__name label")
    const placeOrder = page.locator(".action__submit")
    const orderConfirmation = page.locator(".hero-primary")
    const orderID = page.locator("label.ng-star-inserted")
    const orderTab = page.locator("button[routerlink='/dashboard/myorders']")
    const orderSummary = page.locator("div.email-title")
    

    await page.goto("https://rahulshettyacademy.com/client/#/auth/login")
    // await page.locator("p.login-wrapper-footer-text").click()
    // await firstName.fill("sb1")
    // await lastName.fill("test")
    // await email.fill(emaiId)
    // await phoneNo.fill("1234567890")
    // await dropDOwn.selectOption("Engineer")
    // await radioBtn.check()
    // await pwd.fill(pwdValue)
    // await confirmPwd.fill(pwdValue)
    // await checkbox.click()
    // await registerBtn.click()
    // await expect(page.locator("div[class*='login-wrapper my-auto'] h1")).toContainText("Account Created Successfully")
    // await loginBtn.click()

    await email.fill(emaiId)
    await pwd.fill(pwdValue)
    await loginpage_loginBtn.click()
   // await expect(dashboardHdr).toBeVisible()
   // console.log(await productNames.first().textContent())
   await page.waitForLoadState('networkidle') // below is substitute of this line
    await productNames.last().waitFor()
    const allProducts = await productNames.allTextContents()
    console.log(allProducts)
    const countOfProduct =await  productNames.count()
    console.log(countOfProduct)
    const productName = "ZARA COAT 3"
    for(let i = 0;i<countOfProduct; ++i)
    {
       
        if(await productNames.nth(i).locator("b").textContent() === productName)
        {
            await products.nth(i).locator("text = Add To Cart").click()   
            break     
            
        }
    }
    await cartBtn.click()
    await page.locator("div li",{hasText:productName}).waitFor()
    const product_InCart =page.locator("h3:has-text('ZARA COAT 3')")
    const bool = await product_InCart.isVisible()
    expect(bool).toBeTruthy()
    await checkOut.click()
    await selectCountry.pressSequentially("ind")
    await dropDown_Country.waitFor()
    const optionsCount =await dropDown_Country.locator('button').count()
    for(let i = 0;i<optionsCount;i++)
    {
        let c = (await dropDown_Country.locator('button').nth(i).textContent()).trim()
        if(c === "India")
        {
           
            await dropDown_Country.locator('button').nth(i).click()
            break
        }
    }
    //await page.pause()
    expect(shippingInfo_email).toHaveText(emaiId)
    await placeOrder.click()
    //await page.pause()
    expect(orderConfirmation).toContainText("Thankyou for the order.")
    const orderNumber = (await orderID.textContent()).trim()
    const finalOrderNo = orderNumber.replaceAll("|","").trim()
    console.log("Order Number is "+finalOrderNo)
     
    await orderTab.click()
    //await page.pause()
    // const order_InOrderHistroy = page.locator("[scope='row']",{hasText : finalOrderNo})
    // expect(order_InOrderHistroy).toHaveText(finalOrderNo)
    // await order_InOrderHistroy.locator("xpath=following-sibling::td /button").locator("text =View").click()
    // await page.pause()
    // await expect(orderSummary).toContainText("order summary")

    const rows = page.locator("tbody tr")
    for(let i = 0;i<await rows.count();i++)
    {
        
        const rowOrderID = await rows.nth(i).locator('th').textContent()
        if(orderNumber.includes(rowOrderID))
        {
            await page.pause()
            console.log("Inside if")
            await rows.nth(i).locator("button").locator("text =View").click()
            break 
        }
    }
   // await page.pause()
    await expect(orderSummary).toContainText("order summary")
    const orderNo_OrderSummary =  page.locator("div.col-text")
    expect(orderNo_OrderSummary).toHaveText(finalOrderNo)
   




}
)