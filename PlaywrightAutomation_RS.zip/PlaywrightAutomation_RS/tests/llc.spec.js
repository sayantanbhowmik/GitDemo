const {test,expect} = require('@playwright/test')

test('Playwright special locators',async({page})=>
{
    await page.goto("https://rahulshettyacademy.com/angularpractice/")
    await page.getByLabel("Check me out if you Love IceCreams!").click()
    await page.getByLabel("Employed").check()
    await page.getByLabel("Gender").selectOption("Female")
    await page.getByPlaceholder("Password").fill("abc123")
    await page.getByRole("button",{name : 'Submit'}).click()
    const bool = await page.getByText('Success! The Form has been submitted successfully!.').isVisible({timeout : 10_000})
    expect(bool).toBeTruthy() //5sec default  timeout for expect assertions
    await page.getByRole("link",{name : 'Shop'}).click()
    await page.locator("app-card").filter({hasText : 'Nokia Edge'}).getByRole("button").click()
    await page.pause()
})

test.only('Playwright Test level timeout',async({page})=>
{
    test.setTimeout(20000)
    const slowExpect = expect.configure({timeput : 10000}) //assertion level test
    page.setDefaultTimeout(9000)
    await page.goto("https://rahulshettyacademy.com/angularpractice/")
    await page.getByLabel("Check me out if you Love IceCreams!").click()
    await page.getByLabel("Employed").check()
    await page.getByLabel("Gender").selectOption("Female")
    await page.getByPlaceholder("Password").fill("abc123")
    await page.getByRole("button",{name : 'Submit'}).click()
    const bool = await page.getByText('Success! The Form has been submitted successfully!.').isVisible()
    expect(bool).toBeTruthy() //5sec default  timeout for expect assertions
    await page.getByRole("link",{name : 'Shop'}).click({timeout : 15000})
    await slowExpect(page.locator(".my-4").first()).toContainText("Shop")
    await page.locator("app-card").filter({hasText : 'Nokia Edge'}).getByRole("button").click()
    //await page.pause()
})


