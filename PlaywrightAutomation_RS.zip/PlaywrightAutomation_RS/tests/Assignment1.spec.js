const {test,expect} = require('@playwright/test')
const { login } = require('./Helper/Auth');

//Create a brand new event from the admin panel,
//  then complete a booking for that event, and finally verify the seat count drops by exactly 1.
test('EventHub app test',async({page})=>
{
const Base_URL = "https://eventhub.rahulshettyacademy.com"
const emailValue = "dummy1!@gmail.com"
const pwd = "Ind@1995"
await page.goto(Base_URL)
await page.getByText("Sign in to EventHub")
await page.waitForLoadState('networkidle');
await login(page,{emailId:emailValue , passwordVal:pwd });
await page.getByText("Browse Event")





})

