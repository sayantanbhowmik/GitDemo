const {test,expect} = require('@playwright/test')

test('Browser Context-validating error login',async ({browser})=>
{
    
    const context = await browser.newContext()
    const page = await context.newPage()
    const userName = page.locator("#username")
    const signIn = page.locator("#signInBtn")
     const cardTitles = page.locator(".card-body a")

    await page.goto("https://rahulshettyacademy.com/loginpagePractise/")
    await userName.fill("learning") 
    await page.locator("#password").fill("Learning@830$3mK2") 
    await signIn.click()
    console.log(await page.locator("[style*='block']").textContent())
    await expect(page.locator("[style*='block']")).toContainText("Incorrect")
    await userName.fill("")
    await userName.fill("rahulshettyacademy")
    await signIn.click()
//    console.log(await cardTitles.first().textContent()) 
//    console.log(await cardTitles.nth(1).textContent()) 
    await expect(cardTitles.first()).toBeVisible()
    const allTitles = await cardTitles.allTextContents()
    console.log(allTitles)


    
}
)

test('Page playwright test',async ({page})=>
{
    await page.goto("https://rahulshettyacademy.com/loginpagePractise/")
    
    await expect(await page.title()).toMatch("LoginPage")
}
)
test('UI Control',async ({page})=>
{
    await page.goto("https://rahulshettyacademy.com/loginpagePractise/")
    const userName = page.locator("#username")
    const signIn = page.locator("#signInBtn")
    const dropDown = page.locator("select.form-control")
    const radioButton_User = page.locator("span.checkmark").last()
    const okay_popup = page.locator("#okayBtn")
    const termCheckbox = page.locator("#terms")
    const documentLink = page.locator("[href*='documents-request']")

    await expect(await page.title()).toMatch("LoginPage")
    await dropDown.selectOption("Consultant")

    await radioButton_User.click()
    await okay_popup.click()
    
    console.log(await radioButton_User.isChecked())
    await expect(radioButton_User).toBeChecked()
    
    await termCheckbox.click()
    await expect(termCheckbox).toBeChecked()
   await termCheckbox.uncheck()
   // await page.pause()
    expect(await termCheckbox.isChecked()).toBeFalsy()
    await expect(documentLink).toHaveAttribute('class','blinkingText') 
})

test('child window handle', async ({browser}) =>
{
    const context =await browser.newContext()
    const page =await  context.newPage()
    await page.goto("https://rahulshettyacademy.com/loginpagePractise/")
    const documentLink = page.locator("[href*='documents-request']")
    const userName = page.locator("#username")
    const [newPage] =await Promise.all(
     [
        context.waitForEvent('page'), //listen for any new page to open
        documentLink.click() // new page is opened
     ])
    const text =await newPage.locator('p.red').textContent()
    const arrayText=text.split("@")[1]
    const domain = arrayText.split(".")[0]
    console.log(domain)
   // console.log(text)
    await userName.fill(domain)
    await page.pause()
    console.log(await userName.inputValue())
     
}
)