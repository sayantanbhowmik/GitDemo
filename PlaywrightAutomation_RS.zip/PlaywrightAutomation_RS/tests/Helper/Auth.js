
async function login(page, {emailId, passwordVal } = {}) {

 const email = page.getByPlaceholder("you@email.com")
 const password = page.getByPlaceholder("••••••")
const loginBtn = page.locator("#login-btn")
  await email.fill(emailId);
  await password.fill(passwordVal);
  await loginBtn.click(),

  // Sanity check that login succeeded
  await page.waitForLoadState('networkidle');
}

module.exports = { login };